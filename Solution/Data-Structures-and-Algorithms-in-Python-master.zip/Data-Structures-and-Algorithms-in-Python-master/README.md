Data-Structures-and-Algorithms-in-Python
======================================

My solutions to the exercises in book Data Structures and Algorithms in Python
