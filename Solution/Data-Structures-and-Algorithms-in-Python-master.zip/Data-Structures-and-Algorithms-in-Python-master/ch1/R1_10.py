#!/usr/bin/env python3
# Author: TianJun
# Mail: find_my_way@foxmail.com
# Created Time: 2013/12/16 10:42:12

if __name__ == '__main__':
    for x in range(8, -10, -2):
        print(x)
