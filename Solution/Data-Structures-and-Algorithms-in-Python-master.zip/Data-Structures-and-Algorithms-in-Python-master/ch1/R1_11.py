#!/usr/bin/env python3
# Author: TianJun
# Mail: find_my_way@foxmail.com
# Created Time: 2013/12/16 10:43:55

if __name__ == '__main__':
    print([2**a for a in range(9)])
