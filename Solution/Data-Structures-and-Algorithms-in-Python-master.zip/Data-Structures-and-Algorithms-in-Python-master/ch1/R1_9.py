#!/usr/bin/env python3
# Author: TianJun
# Mail: find_my_way@foxmail.com
# Created Time: 2013/12/16 10:37:57

if __name__ == '__main__':
    for x in range(50, 90, 10):
        print(x)
