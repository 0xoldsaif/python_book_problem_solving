# x = S.pop()
# x > S.pop() ? x : S.pop()
