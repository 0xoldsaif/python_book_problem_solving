#!/usr/bin/env python

from progressions import FibonacciProgression
f = FibonacciProgression(2, 2)
f.print_progression(8)
